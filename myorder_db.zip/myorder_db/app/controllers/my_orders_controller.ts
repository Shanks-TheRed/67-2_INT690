import Menu from '#models/menu';
import OrderItem from '#models/order_item';
import type { HttpContext } from '@adonisjs/core/http'


export default class MyOrdersController {
    async index({ view }:HttpContext){
        const meals = await Menu.query().where('category', 'meal');
        const drinks = await Menu.query().where('category', 'drink');
        return view.render('pages/home', {meals: meals, drinks: drinks});
    }

    async yourOrder({view}:HttpContext){
        const orderItems = await OrderItem.query().preload('menu');
        // const total = await OrderItem.query().sum('quantity as itemCount').first();
        // const itemCount = total.$extras.itemCount;
        const itemCount = orderItems.reduce( (a, v) => a + v.quantity, 0 );
        const totalAmount = orderItems.reduce( (a, v) => a + (v.quantity * v.menu.price), 0);
        return view.render('pages/yourOrder', {orderItems: orderItems, total: itemCount, amount: totalAmount});
    }

    async takeOrder({params, response}:HttpContext){
        const id = params.id;
        const orderItems = await OrderItem.findBy('menuId', id);
        if( !orderItems ){
            const addOrder = await OrderItem.create({
                menuId: id,
            });
        } else {
            orderItems.quantity++;
            await orderItems.save();
        }
        response.redirect().toRoute('menus.yourOrder');
    }

    async removeOrder({params, response}: HttpContext){
        const id = params.id;
        const deleteItem = await OrderItem.find(id);
        if( deleteItem!.quantity > 1 ){
            deleteItem!.quantity--;
            response.redirect().toRoute('menus.yourOrder');
        } else {
            response.redirect().toRoute('menus.removeOrderAll', {id:id});
        };
    }

    async removeOrderAll({params, response}: HttpContext){
        const id = params.id;
        await OrderItem.query().where('id', id).delete();
        response.redirect().toRoute('menus.yourOrder');
    }
}