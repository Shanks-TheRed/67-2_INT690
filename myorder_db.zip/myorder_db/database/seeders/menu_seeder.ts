import Menu from '#models/menu'
import { BaseSeeder } from '@adonisjs/lucid/seeders'

export default class extends BaseSeeder {
  async run() {
    // Write your database queries inside the run method
    await Menu.createMany([
      {
        name: 'ข้าวกระเพาหมูสับ',
        price: 70,
        image: 'image001',
        category: 'meal'
      },
      {
        name: 'ข้าวไก่ผัดขิง',
        price: 80,
        image: 'image002',
        category: 'meal'
      },
      {
        name: 'สุกี้กุ้งแห้ง',
        price: 90,
        image: 'image003',
        category: 'meal'
      },
      {
        name: 'ข้าวผัดหมู',
        price: 70,
        image: 'image004',
        category: 'meal'
      },
      {
        name: 'ข้าวคุกกะปิ',
        price: 85,
        image: 'image005',
        category: 'meal'
      },
      {
        name: 'น้ำแร่',
        price: 20,
        image: 'image006',
        category: 'drink'
      },
      {
        name: 'โค้ก รีฟิล',
        price: 49,
        image: 'image007',
        category: 'drink'
      },
      {
        name: 'น้ำแข็ง',
        price: 2,
        image: 'image008',
        category: 'drink'
      },
      {
        name: 'น้ำชาดำเย็น',
        price: 30,
        image: 'image009',
        category: 'drink'
      },
      {
        name: 'น้ำโอเลี้ยง',
        price: 30,
        image: 'image010',
        category: 'drink'
      },
      {
        name: 'น้ำชามะนาว',
        price: 30,
        image: 'image011',
        category: 'drink'
      }
    ])
  }
}