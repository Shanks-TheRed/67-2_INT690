import vine, { SimpleMessagesProvider } from '@vinejs/vine'


const schema = vine.object({
    poster: vine.string().trim().maxLength(15),
    comment: vine.string().trim(),
});

vine.messagesProvider = new SimpleMessagesProvider({
    'required': 'The {{field}} field is required',
    'string': 'The value of {{field}} field must be a string',
    'poster.maxLength': 'The value of {{field}} field must more than or equal 15 character',
});

export const commentValidator = vine.compile(schema);