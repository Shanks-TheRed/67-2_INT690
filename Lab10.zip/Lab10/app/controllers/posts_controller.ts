import type { HttpContext } from '@adonisjs/core/http'
import Post from '#models/post'
import { createPostValidator } from '#validators/post';


export default class PostsController {

    async index({auth, view}: HttpContext) {
        const user = auth.getUserOrFail();
        const posts = await Post.query()
                                .where('userId', user.id)
                                .withCount('comments', (query) => {
                                    query.as('commentsCount')
                                }).orderBy('id', 'desc');
        return view.render('posts', {posts: posts});
    }

    async show({auth, params, view}: HttpContext) {
        const id = params.id;
        const user = auth.getUserOrFail();
        const post = await Post.query()
                               .where('userId', user.id)
                               .where('id', id)
                               .first();
        return view.render('detail', {post: post});
    }

    async create({view}: HttpContext) {
        return view.render('post');
    }

    async store({auth, request, response}: HttpContext) {
        const user = auth.getUserOrFail();
        const payload = await request.validateUsing(createPostValidator);
        const post = new Post();
        post.userId = user.id;
        post.title = payload.title;
        post.body = payload.body;
        await post.save();
        response.redirect().toRoute('posts.home');
    }

    async edit({auth, params, view}: HttpContext) {
        const id = params.id;
        const user = auth.getUserOrFail();
        const post = await Post.query()
                               .where('userId', user.id)
                               .where('id', id)
                               .first();
        return view.render('post', {post: post});
    }

    async update({auth, params, request, response}: HttpContext) {
        const id = params.id;
        const user = auth.getUserOrFail();
        const post = await Post.query()
                               .where('userId', user.id)
                               .where('id', id)
                               .first();
        const payload = await request.validateUsing(createPostValidator);
        post!.title = payload.title;
        post!.body = payload.body;
        await post?.save();
        response.redirect().toRoute('posts.home');
    }

    async destroy({auth, params, response}: HttpContext) {
        const id = params.id;
        const user = auth.getUserOrFail();
        const post = await Post.query()
                               .where('userId', user.id)
                               .where('id', id)
                               .first();
        await post?.delete();
        response.redirect().toRoute('posts.home');
    }
}