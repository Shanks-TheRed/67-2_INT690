import PostsController from '#controllers/posts_controller'
import { middleware } from '#start/kernel'
import router from '@adonisjs/core/services/router'

router
  .group(() => {
    router
      .group(() => {
        router.resource('/posts', PostsController).apiOnly()
      })
      .prefix('/v1')
  })
  .prefix('/api')
  .use(middleware.auth())
