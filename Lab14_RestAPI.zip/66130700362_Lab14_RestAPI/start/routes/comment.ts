import CommentsController from '#controllers/comments_controller'
import { middleware } from '#start/kernel'
import router from '@adonisjs/core/services/router'

router
  .group(() => {
    router
      .group(() => {
        router
          .resource('/posts.comments', CommentsController)
          .params({ posts: 'id', comments: 'cid' })
          .apiOnly()
      })
      .prefix('/v1')
  })
  .prefix('/api')
  .use(middleware.auth())
