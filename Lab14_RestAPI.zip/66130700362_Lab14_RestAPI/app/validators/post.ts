import vine, { SimpleMessagesProvider } from '@vinejs/vine'

const schema = vine.object({
  title: vine.string().trim().minLength(6),
  body: vine.string().trim(),
})

vine.messagesProvider = new SimpleMessagesProvider({
  'required': 'The {{field}} field is required',
  'string': 'The value of {{field}} field must be a string',
  'title.minLength': 'The value of {{field}} field must more than or equal 6 character',
})

export const createPostValidator = vine.compile(schema)
