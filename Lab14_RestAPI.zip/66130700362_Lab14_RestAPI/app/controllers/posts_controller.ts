import Post from '#models/post'
import type { HttpContext } from '@adonisjs/core/http'

export default class PostsController {
  /**
   * Display a list of resource
   */
  async index({ auth, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const posts = await user.related('posts').query()
    //response.status(200).send(posts)
    response.ok(posts)
  }
  /**
   * Handle form submission for the create action
   */
  async store({ request }: HttpContext) {}
  /**
   * Show individual record
   */
  async show({ params, bouncer, response }: HttpContext) {
    const id = params.id
    const post = await Post.find(id)
    if (!post) {
      return response.notFound('Post not found')
    }
    await bouncer.with('PostPolicy').authorize('view', post)
    response.ok(post)
  }
  /**
   * Handle form submission for the edit action
   */
  async update({ params, request }: HttpContext) {}
  /**
   * Delete record
   */
  async destroy({ params }: HttpContext) {}
}
