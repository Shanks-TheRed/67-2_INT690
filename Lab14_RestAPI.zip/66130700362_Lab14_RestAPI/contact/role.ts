enum Role {
  ADMIN = 'ADMIN',
  USER = 'USER',
}
export default Role
